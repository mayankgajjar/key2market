<?php
// This file was auto-generated from sdk-root/src/data/comprehend/2017-11-27/paginators-1.json
return [ 'pagination' => [ 'ListTopicsDetectionJobs' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
