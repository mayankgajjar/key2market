<?php
// This file was auto-generated from sdk-root/src/data/email/2010-12-01/paginators-1.json
return [ 'pagination' => [ 'ListCustomVerificationEmailTemplates' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', ], 'ListIdentities' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxItems', 'output_token' => 'NextToken', 'result_key' => 'Identities', ], 'ListVerifiedEmailAddresses' => [ 'result_key' => 'VerifiedEmailAddresses', ], ],];
